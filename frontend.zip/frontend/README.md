# 🛠 Service Desk — Frontend

React + TypeScript фронтенд для системи технічної підтримки.

## Структура проекту

```
service-desk/
├── index.html
├── package.json
├── vite.config.ts
├── tsconfig.json
└── src/
    ├── main.tsx              # Точка входу
    ├── App.tsx               # Головний компонент
    ├── api/
    │   └── index.ts          # API клієнт + всі методи
    ├── context/
    │   └── ToastContext.tsx  # Toast-сповіщення
    ├── types/
    │   └── index.ts          # TypeScript типи
    ├── styles/
    │   └── global.css        # Глобальні стилі
    ├── components/
    │   ├── ui.tsx            # Загальні UI компоненти
    │   ├── AuthScreen.tsx    # Екран входу/реєстрації
    │   ├── Sidebar.tsx       # Бокова навігація
    │   ├── CreateProblemModal.tsx
    │   └── AdminModals.tsx   # Модалки для адміна
    └── pages/
        ├── ProblemsList.tsx  # Список заявок
        ├── ProblemDetail.tsx # Деталі заявки
        └── ProfilePage.tsx   # Профіль користувача
```

## Швидкий старт

### 1. Встановити залежності
```bash
npm install
```

### 2. Налаштувати URL бекенду

Відкрийте `src/api/index.ts` і змініть першу строку:
```ts
const API_BASE = 'http://localhost:8000'  // ← ваш бекенд
```

### 3. Запустити
```bash
npm run dev
```

Сайт відкриється на http://localhost:3000

### 4. Build для продакшн
```bash
npm run build
```

## CORS

Переконайтесь що бекенд дозволяє запити з `http://localhost:3000`.  
У вашому `main.py` змініть:

```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # або ["*"] для розробки
    ...
)
```
